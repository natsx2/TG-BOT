import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { BotUser } from "@workspace/api-client-react";
import { useApproveUser, getListPendingUsersQueryKey, getListUsersQueryKey, getGetUserStatsQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check } from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";

const approveSchema = z.object({
  accessUsername: z.string().min(3, "Username must be at least 3 characters"),
  accessPassword: z.string().min(6, "Password must be at least 6 characters"),
  durationMode: z.enum(["permanent", "custom"]),
  durationDays: z.coerce.number().min(0).optional().nullable(),
  durationHours: z.coerce.number().min(0).optional().nullable(),
  durationMinutes: z.coerce.number().min(0).optional().nullable(),
  durationSeconds: z.coerce.number().min(0).optional().nullable(),
  notes: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.durationMode === "custom") {
    const hasDuration = !!(data.durationDays || data.durationHours || data.durationMinutes || data.durationSeconds);
    if (!hasDuration) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Please specify at least one duration value",
        path: ["durationMode"],
      });
    }
  }
});

type ApproveFormValues = z.infer<typeof approveSchema>;

interface ApproveUserDialogProps {
  user: BotUser | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ApproveUserDialog({ user, open, onOpenChange }: ApproveUserDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const approveMutation = useApproveUser();

  const form = useForm<ApproveFormValues>({
    resolver: zodResolver(approveSchema),
    defaultValues: {
      accessUsername: "",
      accessPassword: "",
      durationMode: "permanent",
      durationDays: null,
      durationHours: null,
      durationMinutes: null,
      durationSeconds: null,
      notes: "",
    },
  });

  // Generate username based on telegram ID if empty when opened
  useState(() => {
    if (open && user && !form.getValues().accessUsername) {
      form.setValue("accessUsername", user.telegramUsername || `user_${user.telegramId}`);
    }
  });

  const durationMode = form.watch("durationMode");

  const onSubmit = (data: ApproveFormValues) => {
    if (!user) return;

    const permanent = data.durationMode === "permanent";
    
    approveMutation.mutate(
      {
        id: user.id,
        data: {
          accessUsername: data.accessUsername,
          accessPassword: data.accessPassword,
          permanent,
          durationDays: permanent ? null : data.durationDays,
          durationHours: permanent ? null : data.durationHours,
          durationMinutes: permanent ? null : data.durationMinutes,
          durationSeconds: permanent ? null : data.durationSeconds,
          notes: data.notes,
        }
      },
      {
        onSuccess: () => {
          toast({
            title: "Access Granted",
            description: `User ${user.telegramUsername || user.firstName} has been approved.`,
          });
          
          // Invalidate relevant queries
          queryClient.invalidateQueries({ queryKey: getListPendingUsersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetUserStatsQueryKey() });
          
          onOpenChange(false);
          form.reset();
        },
        onError: (error: any) => {
          toast({
            title: "Approval Failed",
            description: error.data?.error || "Could not approve user.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] border-border bg-card text-card-foreground">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2">
            <Check className="w-5 h-5 text-green-500" />
            APPROVE ACCESS
          </DialogTitle>
          <DialogDescription>
            Grant bot access for {user?.firstName} {user?.lastName} ({user?.telegramId}).
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="accessUsername"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Bot Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter username" {...field} className="font-mono bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="accessPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Bot Password</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter password" {...field} className="font-mono bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="durationMode"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Access Duration</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0 p-3 border border-border rounded-md bg-background">
                        <FormControl>
                          <RadioGroupItem value="permanent" />
                        </FormControl>
                        <FormLabel className="font-normal flex-1 cursor-pointer">
                          Permanent Access
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0 p-3 border border-border rounded-md bg-background">
                        <FormControl>
                          <RadioGroupItem value="custom" />
                        </FormControl>
                        <FormLabel className="font-normal flex-1 cursor-pointer">
                          Temporary Access
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {durationMode === "custom" && (
              <div className="grid grid-cols-4 gap-2 bg-muted/30 p-3 rounded-md border border-border">
                <FormField
                  control={form.control}
                  name="durationDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Days</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationHours"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Hours</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationMinutes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Mins</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationSeconds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Secs</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            )}

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Admin Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Optional notes about this approval..." 
                      className="resize-none bg-background font-mono text-sm" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={approveMutation.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                {approveMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Check className="w-4 h-4 mr-2" />
                )}
                Approve User
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
