import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { BotUser } from "@workspace/api-client-react";
import { useUpdateUserAccess, getListUsersQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Key } from "lucide-react";
import { useEffect } from "react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const updateAccessSchema = z.object({
  accessUsername: z.string().min(3, "Username must be at least 3 characters").optional().or(z.literal('')),
  accessPassword: z.string().min(6, "Password must be at least 6 characters").optional().or(z.literal('')),
  durationMode: z.enum(["unchanged", "permanent", "custom"]),
  durationDays: z.coerce.number().min(0).optional().nullable(),
  durationHours: z.coerce.number().min(0).optional().nullable(),
  durationMinutes: z.coerce.number().min(0).optional().nullable(),
  durationSeconds: z.coerce.number().min(0).optional().nullable(),
}).superRefine((data, ctx) => {
  if (data.durationMode === "custom") {
    const hasDuration = !!(data.durationDays || data.durationHours || data.durationMinutes || data.durationSeconds);
    if (!hasDuration) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Please specify at least one duration value",
        path: ["durationMode"],
      });
    }
  }
});

type UpdateAccessFormValues = z.infer<typeof updateAccessSchema>;

interface UpdateAccessDialogProps {
  user: BotUser | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function UpdateAccessDialog({ user, open, onOpenChange }: UpdateAccessDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateMutation = useUpdateUserAccess();

  const form = useForm<UpdateAccessFormValues>({
    resolver: zodResolver(updateAccessSchema),
    defaultValues: {
      accessUsername: "",
      accessPassword: "",
      durationMode: "unchanged",
      durationDays: null,
      durationHours: null,
      durationMinutes: null,
      durationSeconds: null,
    },
  });

  useEffect(() => {
    if (open && user) {
      form.reset({
        accessUsername: user.accessUsername || "",
        accessPassword: "", // Don't prefill password
        durationMode: "unchanged",
        durationDays: null,
        durationHours: null,
        durationMinutes: null,
        durationSeconds: null,
      });
    }
  }, [open, user, form]);

  const durationMode = form.watch("durationMode");

  const onSubmit = (data: UpdateAccessFormValues) => {
    if (!user) return;

    let durationData = {};
    if (data.durationMode === "permanent") {
      durationData = { permanent: true, durationDays: null, durationHours: null, durationMinutes: null, durationSeconds: null };
    } else if (data.durationMode === "custom") {
      durationData = { 
        permanent: false, 
        durationDays: data.durationDays, 
        durationHours: data.durationHours, 
        durationMinutes: data.durationMinutes, 
        durationSeconds: data.durationSeconds 
      };
    }

    updateMutation.mutate(
      {
        id: user.id,
        data: {
          accessUsername: data.accessUsername || undefined,
          accessPassword: data.accessPassword || undefined,
          ...durationData
        }
      },
      {
        onSuccess: () => {
          toast({
            title: "Access Updated",
            description: `Credentials updated for ${user.telegramUsername || user.firstName}.`,
          });
          
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          
          onOpenChange(false);
        },
        onError: (error: any) => {
          toast({
            title: "Update Failed",
            description: error.data?.error || "Could not update access.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] border-border bg-card text-card-foreground">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            EDIT ACCESS
          </DialogTitle>
          <DialogDescription>
            Update credentials or expiry for {user?.firstName} {user?.lastName}. Leave password blank to keep it unchanged.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="accessUsername"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Bot Username</FormLabel>
                    <FormControl>
                      <Input placeholder={user?.accessUsername || "Enter username"} {...field} className="font-mono bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="accessPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-mono text-xs text-muted-foreground uppercase">New Password</FormLabel>
                    <FormControl>
                      <Input placeholder="Leave blank to keep" {...field} className="font-mono bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="durationMode"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Access Expiry</FormLabel>
                  <FormControl>
                    <RadioGroup
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      className="flex flex-col space-y-1"
                    >
                      <FormItem className="flex items-center space-x-3 space-y-0 p-3 border border-border rounded-md bg-background">
                        <FormControl>
                          <RadioGroupItem value="unchanged" />
                        </FormControl>
                        <FormLabel className="font-normal flex-1 cursor-pointer">
                          Keep current expiry
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0 p-3 border border-border rounded-md bg-background">
                        <FormControl>
                          <RadioGroupItem value="permanent" />
                        </FormControl>
                        <FormLabel className="font-normal flex-1 cursor-pointer">
                          Make Permanent
                        </FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center space-x-3 space-y-0 p-3 border border-border rounded-md bg-background">
                        <FormControl>
                          <RadioGroupItem value="custom" />
                        </FormControl>
                        <FormLabel className="font-normal flex-1 cursor-pointer">
                          Set New Temporary Expiry
                        </FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {durationMode === "custom" && (
              <div className="grid grid-cols-4 gap-2 bg-muted/30 p-3 rounded-md border border-border">
                <FormField
                  control={form.control}
                  name="durationDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Days</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationHours"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Hours</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationMinutes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Mins</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationSeconds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs">Secs</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" {...field} value={field.value || ""} className="h-8" />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={updateMutation.isPending}>
                {updateMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Changes
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
