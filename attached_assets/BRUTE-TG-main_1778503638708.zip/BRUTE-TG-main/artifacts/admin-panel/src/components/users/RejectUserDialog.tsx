import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { BotUser } from "@workspace/api-client-react";
import { useRejectUser, getListPendingUsersQueryKey, getListUsersQueryKey, getGetUserStatsQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, X } from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const rejectSchema = z.object({
  notes: z.string().min(1, "Please provide a reason for rejection"),
});

type RejectFormValues = z.infer<typeof rejectSchema>;

interface RejectUserDialogProps {
  user: BotUser | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RejectUserDialog({ user, open, onOpenChange }: RejectUserDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const rejectMutation = useRejectUser();

  const form = useForm<RejectFormValues>({
    resolver: zodResolver(rejectSchema),
    defaultValues: {
      notes: "",
    },
  });

  const onSubmit = (data: RejectFormValues) => {
    if (!user) return;

    rejectMutation.mutate(
      {
        id: user.id,
        data: {
          notes: data.notes,
        }
      },
      {
        onSuccess: () => {
          toast({
            title: "Request Rejected",
            description: `User ${user.telegramUsername || user.firstName} has been rejected.`,
          });
          
          queryClient.invalidateQueries({ queryKey: getListPendingUsersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetUserStatsQueryKey() });
          
          onOpenChange(false);
          form.reset();
        },
        onError: (error: any) => {
          toast({
            title: "Rejection Failed",
            description: error.data?.error || "Could not reject user.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] border-border bg-card text-card-foreground">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2 text-red-500">
            <X className="w-5 h-5" />
            REJECT ACCESS
          </DialogTitle>
          <DialogDescription>
            Deny bot access for {user?.firstName} {user?.lastName} ({user?.telegramId}). This action will notify the user if enabled.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="font-mono text-xs text-muted-foreground uppercase">Reason for Rejection</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Why is this request being denied?" 
                      className="resize-none bg-background font-mono text-sm min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="mt-6">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="destructive" disabled={rejectMutation.isPending}>
                {rejectMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <X className="w-4 h-4 mr-2" />
                )}
                Reject Request
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
