import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useAdminLogout } from "@workspace/api-client-react";
import {
  LayoutDashboard,
  Users,
  Clock,
  Settings,
  LogOut,
  Shield,
  Menu,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";

interface SidebarProps {
  mobile?: boolean;
  closeMobile?: () => void;
}

function SidebarNav({ mobile, closeMobile }: SidebarProps) {
  const [location] = useLocation();
  const { logout } = useAuth();
  const logoutMutation = useAdminLogout();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        logout();
      },
    });
  };

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/users", label: "All Users", icon: Users },
    { href: "/users/pending", label: "Pending Approvals", icon: Clock },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground border-r border-sidebar-border w-64">
      <div className="p-6 flex items-center gap-3">
        <Shield className="w-6 h-6 text-primary" />
        <span className="font-bold text-lg font-mono tracking-tight text-white">BRUTE_TG</span>
      </div>
      
      <div className="px-4 py-2">
        <div className="text-xs font-mono text-muted-foreground mb-4 uppercase tracking-wider">Navigation</div>
        <nav className="space-y-1">
          {navItems.map((item) => {
            const active = location === item.href || location.startsWith(`${item.href}/`);
            return (
              <Link key={item.href} href={item.href} onClick={closeMobile} className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${active ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"}`}>
                <item.icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-4">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block h-full">
        <SidebarNav />
      </div>

      {/* Mobile Sidebar & Header */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="md:hidden h-14 border-b border-border bg-card flex items-center px-4 shrink-0">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="-ml-2">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 border-r-sidebar-border bg-sidebar text-sidebar-foreground">
              <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
              <SidebarNav mobile />
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2 ml-4">
            <Shield className="w-5 h-5 text-primary" />
            <span className="font-bold font-mono tracking-tight">BRUTE_TG</span>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
