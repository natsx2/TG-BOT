import { useState } from "react";
import { useListUsers, useDeleteUser, BotUser, getListUsersQueryKey, getGetUserStatsQueryKey, ListUsersStatus } from "@workspace/api-client-react";
import { formatDistanceToNow, format } from "date-fns";
import { Search, Filter, MoreHorizontal, Key, Trash2, CheckCircle2, XCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UpdateAccessDialog } from "@/components/users/UpdateAccessDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Users() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const queryParams = statusFilter !== "all" ? { status: statusFilter as ListUsersStatus } : undefined;
  const { data: users, isLoading } = useListUsers(queryParams);
  const deleteMutation = useDeleteUser();

  const [selectedUser, setSelectedUser] = useState<BotUser | null>(null);
  const [updateDialogOpen, setUpdateDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const filteredUsers = users?.filter((u) => {
    if (!search) return true;
    const term = search.toLowerCase();
    return (
      u.telegramId.toLowerCase().includes(term) ||
      (u.telegramUsername && u.telegramUsername.toLowerCase().includes(term)) ||
      (u.firstName && u.firstName.toLowerCase().includes(term)) ||
      (u.accessUsername && u.accessUsername.toLowerCase().includes(term))
    );
  });

  const handleDelete = () => {
    if (!selectedUser) return;
    deleteMutation.mutate(
      { id: selectedUser.id },
      {
        onSuccess: () => {
          toast({ description: "User deleted successfully" });
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetUserStatsQueryKey() });
          setDeleteDialogOpen(false);
        },
        onError: () => {
          toast({ description: "Failed to delete user", variant: "destructive" });
        }
      }
    );
  };

  const getStatusBadge = (status: string, expiresAt: string | null | undefined) => {
    switch (status) {
      case "approved":
        if (!expiresAt) {
          return <Badge className="bg-green-500/10 text-green-500 border-green-500/20 font-mono text-xs">PERMANENT</Badge>;
        }
        return <Badge className="bg-green-500/10 text-green-500 border-green-500/20 font-mono text-xs">APPROVED</Badge>;
      case "pending":
        return <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20 font-mono text-xs">PENDING</Badge>;
      case "rejected":
        return <Badge className="bg-red-500/10 text-red-500 border-red-500/20 font-mono text-xs">REJECTED</Badge>;
      default:
        return <Badge variant="outline" className="font-mono text-xs">{status.toUpperCase()}</Badge>;
    }
  };

  const getExpiryText = (expiresAt: string | null | undefined, status: string) => {
    if (status !== "approved") return "-";
    if (!expiresAt) return <span className="text-green-500 font-mono">No expiry</span>;
    
    const expiryDate = new Date(expiresAt);
    const isExpired = expiryDate < new Date();
    
    return (
      <span className={`font-mono ${isExpired ? "text-red-500" : ""}`}>
        {isExpired ? "Expired " : "Expires "}
        {formatDistanceToNow(expiryDate, { addSuffix: true })}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-mono tracking-tight">DIRECTORY</h1>
          <p className="text-muted-foreground mt-2">Manage all registered users and their access.</p>
        </div>
      </div>

      <Card className="border-border bg-card/50 backdrop-blur overflow-hidden">
        <div className="p-4 border-b border-border flex flex-col sm:flex-row gap-4 items-center justify-between bg-muted/20">
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by ID, username, or name..."
              className="pl-9 font-mono bg-background border-border"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px] font-mono border-border bg-background">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ALL STATUSES</SelectItem>
                <SelectItem value="pending">PENDING</SelectItem>
                <SelectItem value="approved">APPROVED</SelectItem>
                <SelectItem value="rejected">REJECTED</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-muted/40 font-mono tracking-wider">
              <tr>
                <th className="px-6 py-4 font-medium">User</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Access Credentials</th>
                <th className="px-6 py-4 font-medium">Expiry</th>
                <th className="px-6 py-4 font-medium">Registered</th>
                <th className="px-6 py-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i}>
                    <td className="px-6 py-4"><Skeleton className="h-10 w-32" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-6 w-20" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-6 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-6 w-24" /></td>
                    <td className="px-6 py-4"><Skeleton className="h-6 w-24" /></td>
                    <td className="px-6 py-4 text-right"><Skeleton className="h-8 w-8 ml-auto" /></td>
                  </tr>
                ))
              ) : filteredUsers?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center">
                      <Search className="h-8 w-8 mb-4 opacity-20" />
                      <p className="font-mono">NO RECORDS FOUND</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredUsers?.map((user) => (
                  <tr key={user.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="font-medium text-foreground">
                          {user.firstName} {user.lastName}
                        </span>
                        <span className="text-xs text-muted-foreground font-mono mt-1 flex gap-2">
                          <span>{user.telegramId}</span>
                          {user.telegramUsername && <span>@{user.telegramUsername}</span>}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(user.status, user.expiresAt)}
                    </td>
                    <td className="px-6 py-4">
                      {user.accessUsername ? (
                        <div className="font-mono text-xs bg-muted/50 px-2 py-1 rounded border border-border inline-block">
                          {user.accessUsername}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-xs">
                      {getExpiryText(user.expiresAt, user.status)}
                    </td>
                    <td className="px-6 py-4 text-xs text-muted-foreground font-mono">
                      {format(new Date(user.registeredAt), 'MMM d, yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="font-mono text-xs border-border bg-popover">
                          <DropdownMenuLabel className="font-sans text-xs text-muted-foreground">ACTIONS</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          {user.status === "approved" && (
                            <DropdownMenuItem onClick={() => { setSelectedUser(user); setUpdateDialogOpen(true); }} className="cursor-pointer">
                              <Key className="w-4 h-4 mr-2" />
                              Edit Access
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem 
                            onClick={() => { setSelectedUser(user); setDeleteDialogOpen(true); }}
                            className="text-red-500 focus:text-red-500 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Record
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <UpdateAccessDialog 
        user={selectedUser} 
        open={updateDialogOpen} 
        onOpenChange={setUpdateDialogOpen} 
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="border-border bg-card">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-mono text-red-500 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              CONFIRM DELETION
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedUser?.firstName} ({selectedUser?.telegramId})? This action cannot be undone and will immediately revoke any active access.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete} 
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Confirm Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
