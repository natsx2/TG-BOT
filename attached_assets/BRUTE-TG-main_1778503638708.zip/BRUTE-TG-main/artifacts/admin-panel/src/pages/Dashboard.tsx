import { useGetUserStats, useListPendingUsers } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Shield, Clock, Users, XCircle, CheckCircle2, ChevronRight, Activity } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetUserStats();
  const { data: pendingUsers, isLoading: pendingLoading } = useListPendingUsers();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-mono tracking-tight">DASHBOARD</h1>
        <p className="text-muted-foreground mt-2">System overview and pending actions.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Users"
          value={stats?.total}
          icon={Users}
          loading={statsLoading}
          color="text-blue-500"
        />
        <StatsCard
          title="Pending Approvals"
          value={stats?.pending}
          icon={Clock}
          loading={statsLoading}
          color="text-amber-500"
        />
        <StatsCard
          title="Approved Access"
          value={stats?.approved}
          icon={CheckCircle2}
          loading={statsLoading}
          color="text-green-500"
        />
        <StatsCard
          title="Rejected Requests"
          value={stats?.rejected}
          icon={XCircle}
          loading={statsLoading}
          color="text-red-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Pending Users Feed */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold font-mono tracking-tight flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              ACTION REQUIRED
            </h2>
            <Button variant="outline" size="sm" asChild>
              <Link href="/users/pending">View All <ChevronRight className="w-4 h-4 ml-1" /></Link>
            </Button>
          </div>

          <Card className="border-border bg-card/50 backdrop-blur">
            <CardContent className="p-0">
              {pendingLoading ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center gap-4">
                      <Skeleton className="h-10 w-10 rounded-full" />
                      <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-1/3" />
                        <Skeleton className="h-3 w-1/4" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : pendingUsers?.length === 0 ? (
                <div className="p-12 text-center text-muted-foreground flex flex-col items-center">
                  <Shield className="w-12 h-12 mb-4 opacity-20" />
                  <p className="font-mono">NO PENDING REQUESTS</p>
                  <p className="text-sm mt-1">All access requests have been processed.</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {pendingUsers?.slice(0, 5).map((user) => (
                    <div key={user.id} className="p-4 flex items-center justify-between hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center border border-amber-500/20">
                          <Clock className="w-5 h-5 text-amber-500" />
                        </div>
                        <div>
                          <p className="font-medium">
                            {user.firstName} {user.lastName} 
                            {user.telegramUsername && <span className="text-muted-foreground ml-2">@{user.telegramUsername}</span>}
                          </p>
                          <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground font-mono">
                            <span>ID: {user.telegramId}</span>
                            <span>•</span>
                            <span>{formatDistanceToNow(new Date(user.registeredAt), { addSuffix: true })}</span>
                          </div>
                        </div>
                      </div>
                      <Button size="sm" asChild>
                        <Link href="/users/pending">Review</Link>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* System Info Sidebar */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold font-mono tracking-tight flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            SYSTEM STATUS
          </h2>
          
          <Card className="border-border bg-card/50 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono text-muted-foreground">GATEWAY HEALTH</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <div className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </div>
                <span className="font-bold text-green-500 font-mono">OPERATIONAL</span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card/50 backdrop-blur">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono text-muted-foreground">QUICK LINKS</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-2">
              <Button variant="outline" className="justify-start font-mono text-xs" asChild>
                <Link href="/users?status=approved">
                  <CheckCircle2 className="w-4 h-4 mr-2 text-green-500" />
                  View Active Sessions
                </Link>
              </Button>
              <Button variant="outline" className="justify-start font-mono text-xs" asChild>
                <Link href="/users?status=rejected">
                  <XCircle className="w-4 h-4 mr-2 text-red-500" />
                  View Blocked Users
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, value, icon: Icon, loading, color }: { title: string; value?: number; icon: any; loading: boolean; color: string }) {
  return (
    <Card className="border-border bg-card/50 backdrop-blur overflow-hidden relative">
      <div className={`absolute top-0 right-0 p-4 opacity-10 ${color}`}>
        <Icon className="w-16 h-16" />
      </div>
      <CardHeader className="pb-2 relative z-10">
        <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{title}</CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        {loading ? (
          <Skeleton className="h-10 w-20" />
        ) : (
          <div className={`text-4xl font-bold font-mono ${color}`}>{value ?? 0}</div>
        )}
      </CardContent>
    </Card>
  );
}
