import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useUpdateAdminCredentials, useGetAdminMe } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Key, Loader2, Save } from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const settingsSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newUsername: z.string().min(3, "Username must be at least 3 characters").optional().or(z.literal('')),
  newPassword: z.string().min(6, "New password must be at least 6 characters").optional().or(z.literal('')),
  confirmPassword: z.string().optional().or(z.literal('')),
}).superRefine((data, ctx) => {
  if (data.newPassword && data.newPassword !== data.confirmPassword) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Passwords do not match",
      path: ["confirmPassword"],
    });
  }
  if (!data.newUsername && !data.newPassword) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Provide either a new username or new password",
      path: ["newUsername"],
    });
  }
});

type SettingsFormValues = z.infer<typeof settingsSchema>;

export default function Settings() {
  const { toast } = useToast();
  const { username, setAuth, token } = useAuth();
  const updateMutation = useUpdateAdminCredentials();
  
  const form = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      currentPassword: "",
      newUsername: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  const onSubmit = (data: SettingsFormValues) => {
    updateMutation.mutate(
      {
        data: {
          currentPassword: data.currentPassword,
          newUsername: data.newUsername || undefined,
          newPassword: data.newPassword || undefined,
        }
      },
      {
        onSuccess: (res) => {
          toast({
            title: "Settings Updated",
            description: "Admin credentials have been updated successfully.",
          });
          
          if (res.token && res.username) {
            setAuth(res.token, res.username);
          }
          
          form.reset({
            currentPassword: "",
            newUsername: "",
            newPassword: "",
            confirmPassword: "",
          });
        },
        onError: (error: any) => {
          toast({
            title: "Update Failed",
            description: error.data?.error || "Could not update credentials. Check your current password.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold font-mono tracking-tight">SYSTEM SETTINGS</h1>
        <p className="text-muted-foreground mt-2">Manage administrator access credentials.</p>
      </div>

      <Card className="border-border bg-card/50 backdrop-blur">
        <CardHeader>
          <CardTitle className="font-mono flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            ADMIN CREDENTIALS
          </CardTitle>
          <CardDescription>
            Update your login username or password. You must provide your current password to make changes.
            Current username: <strong className="text-foreground">{username}</strong>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="bg-muted/30 p-4 rounded-md border border-border mb-6">
                <FormField
                  control={form.control}
                  name="currentPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Current Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} className="font-mono bg-background max-w-md" />
                      </FormControl>
                      <FormDescription>Required to authorize any changes.</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <h3 className="font-mono text-sm font-bold text-foreground border-b border-border pb-2">NEW CREDENTIALS</h3>
                <p className="text-xs text-muted-foreground mb-4">Leave fields blank if you don't want to change them.</p>

                <FormField
                  control={form.control}
                  name="newUsername"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-mono text-xs uppercase text-muted-foreground">New Username</FormLabel>
                      <FormControl>
                        <Input placeholder={username || "New username"} {...field} className="font-mono bg-background max-w-md" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid sm:grid-cols-2 gap-4 max-w-2xl">
                  <FormField
                    control={form.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase text-muted-foreground">New Password</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} className="font-mono bg-background" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="font-mono text-xs uppercase text-muted-foreground">Confirm New Password</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} className="font-mono bg-background" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Button type="submit" disabled={updateMutation.isPending} className="font-mono tracking-wide">
                {updateMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                APPLY CHANGES
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
