import { useState } from "react";
import { useListPendingUsers } from "@workspace/api-client-react";
import { BotUser } from "@workspace/api-client-react";
import { formatDistanceToNow } from "date-fns";
import { Shield, Clock, CheckCircle2, XCircle } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ApproveUserDialog } from "@/components/users/ApproveUserDialog";
import { RejectUserDialog } from "@/components/users/RejectUserDialog";

export default function PendingUsers() {
  const { data: pendingUsers, isLoading } = useListPendingUsers();
  
  const [selectedUser, setSelectedUser] = useState<BotUser | null>(null);
  const [approveDialogOpen, setApproveDialogOpen] = useState(false);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-mono tracking-tight">PENDING REQUESTS</h1>
        <p className="text-muted-foreground mt-2">Review and process new bot access applications.</p>
      </div>

      {isLoading ? (
        <div className="grid gap-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="border-border bg-card/50 backdrop-blur">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-48" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Skeleton className="h-10 w-24" />
                    <Skeleton className="h-10 w-24" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : pendingUsers?.length === 0 ? (
        <Card className="border-dashed border-border bg-card/20 py-20 flex flex-col items-center justify-center text-center">
          <Shield className="w-16 h-16 text-muted-foreground opacity-20 mb-4" />
          <h2 className="text-xl font-mono font-bold">QUEUE EMPTY</h2>
          <p className="text-muted-foreground mt-2 max-w-sm">
            There are no pending requests at this time. New applications will appear here.
          </p>
        </Card>
      ) : (
        <div className="grid gap-4">
          {pendingUsers?.map((user) => (
            <Card key={user.id} className="border-border bg-card/50 backdrop-blur hover:bg-card/80 transition-colors">
              <CardContent className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start md:items-center gap-4">
                  <div className="hidden md:flex h-12 w-12 rounded-full bg-amber-500/10 items-center justify-center border border-amber-500/20 shrink-0">
                    <Clock className="w-6 h-6 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg flex items-center gap-2">
                      {user.firstName} {user.lastName}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-2 text-sm font-mono text-muted-foreground">
                      <div className="bg-muted px-2 py-1 rounded text-xs border border-border">
                        ID: {user.telegramId}
                      </div>
                      {user.telegramUsername && (
                        <div className="text-primary">@{user.telegramUsername}</div>
                      )}
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDistanceToNow(new Date(user.registeredAt), { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 shrink-0 mt-4 md:mt-0 pt-4 md:pt-0 border-t md:border-t-0 border-border">
                  <Button 
                    variant="outline" 
                    className="text-red-500 hover:text-red-500 hover:bg-red-500/10 font-mono tracking-wide"
                    onClick={() => {
                      setSelectedUser(user);
                      setRejectDialogOpen(true);
                    }}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    REJECT
                  </Button>
                  <Button 
                    className="bg-green-600 hover:bg-green-700 text-white font-mono tracking-wide"
                    onClick={() => {
                      setSelectedUser(user);
                      setApproveDialogOpen(true);
                    }}
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    APPROVE
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <ApproveUserDialog 
        user={selectedUser} 
        open={approveDialogOpen} 
        onOpenChange={setApproveDialogOpen} 
      />
      
      <RejectUserDialog 
        user={selectedUser} 
        open={rejectDialogOpen} 
        onOpenChange={setRejectDialogOpen} 
      />
    </div>
  );
}
