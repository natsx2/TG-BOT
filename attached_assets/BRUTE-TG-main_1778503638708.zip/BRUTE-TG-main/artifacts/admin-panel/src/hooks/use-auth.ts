import { create } from "zustand";

interface AuthState {
  token: string | null;
  username: string | null;
  setAuth: (token: string | null, username: string | null) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  token: localStorage.getItem("brutetg_token"),
  username: localStorage.getItem("brutetg_username"),
  setAuth: (token, username) => {
    if (token) {
      localStorage.setItem("brutetg_token", token);
    } else {
      localStorage.removeItem("brutetg_token");
    }
    if (username) {
      localStorage.setItem("brutetg_username", username);
    } else {
      localStorage.removeItem("brutetg_username");
    }
    set({ token, username });
  },
  logout: () => {
    localStorage.removeItem("brutetg_token");
    localStorage.removeItem("brutetg_username");
    set({ token: null, username: null });
  },
}));